Bus Stop Composite Day

Composite day (e.g. typical weekday) number of boardings and alightings for each bus stop by fiscal year.

Files are separated by fiscal year (July 1 � June 30).
