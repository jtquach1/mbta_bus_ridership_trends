Bus Trip Composite Day

Average weekday, Saturday, and Sunday daily boardings by fiscal year for each bus trip. 

Data is based on automatic passenger counters (APC). 

APCs are not on all buses, so a sample is taken and scaled to the total amount of service run.

Files are separated by fiscal year (July 1 � June 30).
